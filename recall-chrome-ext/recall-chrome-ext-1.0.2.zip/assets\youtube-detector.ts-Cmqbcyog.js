(function(){function f(e){try{const t=new URL(e);return t.hostname.includes("youtube.com")&&t.pathname==="/watch"?t.searchParams.get("v"):t.hostname==="youtu.be"?t.pathname.slice(1):t.hostname.includes("youtube.com")&&t.pathname.startsWith("/shorts/")||t.hostname.includes("youtube.com")&&t.pathname.startsWith("/embed/")?t.pathname.split("/")[2]:null}catch{return null}}const v="https://youtube-recall.vercel.app";let r=null,s=null,d=null;function p(){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",i):i(),T()}function i(){const e=f(window.location.href);if(!e){m(),u();return}e===d&&(r||s)||(d=e,m(),u(),y()||b())}function b(){r=document.createElement("div"),r.id="recall-floating-button",r.className="recall-floating-button",r.innerHTML=`
    <button class="recall-btn" title="Save to Recall">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
      </svg>
      <span class="recall-btn-text">Save</span>
    </button>
  `,document.body.appendChild(r);const e=r.querySelector(".recall-btn");e==null||e.addEventListener("click",h)}function y(){const e=document.querySelector("ytd-watch-metadata #top-level-buttons-computed")||document.querySelector("#top-level-buttons-computed");if(!e)return!1;if(e.querySelector(".recall-inline-button"))return!0;const t=document.createElement("button");return t.className="recall-inline-button yt-spec-button-shape-next yt-spec-button-shape-next--tonal yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m",t.setAttribute("aria-label","Save to Recall"),t.innerHTML=`
    <span class="recall-inline-icon" aria-hidden="true">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
      </svg>
    </span>
    <span class="recall-inline-text">Save</span>
  `,t.addEventListener("click",h),e.appendChild(t),s=t,!0}function u(){r&&(r.remove(),r=null)}function m(){s&&(s.remove(),s=null)}async function h(){if(!(await chrome.runtime.sendMessage({action:"checkAuth"})).authenticated){l("Please sign in to Recall first","error"),window.open(`${v}/auth`,"_blank");return}w()}async function w(){const e=document.createElement("div");e.id="recall-modal",e.className="recall-modal",e.innerHTML=`
    <div class="recall-modal-overlay"></div>
    <div class="recall-modal-content">
      <div class="recall-modal-header">
        <h3>Save to Folder</h3>
        <button class="recall-modal-close">&times;</button>
      </div>
      <div class="recall-modal-body">
        <div class="recall-loading">Loading folders...</div>
      </div>
    </div>
  `,document.body.appendChild(e);const t=e.querySelector(".recall-modal-close"),o=e.querySelector(".recall-modal-overlay"),n=()=>{e.remove()};t==null||t.addEventListener("click",n),o==null||o.addEventListener("click",n);try{const a=await g();S(e,a)}catch(a){console.error("Error loading folders:",a);const c=e.querySelector(".recall-modal-body");c&&(c.innerHTML=`
        <div class="recall-error">
          ${a instanceof Error?a.message:"Failed to load folders. Please try again."}
        </div>
      `)}}async function g(){const e=await chrome.runtime.sendMessage({action:"getFolders"});if(!(e!=null&&e.success))throw new Error((e==null?void 0:e.error)||"Failed to fetch folders");return e.folders||[]}function S(e,t){const o=e.querySelector(".recall-modal-body");if(o){if(t.length===0){o.innerHTML=`
      <div class="recall-empty">
        No folders found. Create one in the web app first.
      </div>
    `;return}o.innerHTML=t.map(n=>`
      <button class="recall-folder-item" data-folder-id="${n.id}">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
        </svg>
        <span>${n.name}${n.is_default?" (default)":""}</span>
      </button>
    `).join(""),o.querySelectorAll(".recall-folder-item").forEach(n=>{n.addEventListener("click",async a=>{const c=a.currentTarget.dataset.folderId;c&&(await M(c),e.remove())})})}}function L(){const e=document.querySelector("video");return!e||Number.isNaN(e.currentTime)?0:Math.floor(e.currentTime)}async function M(e){const t=window.location.href,o=L();l("Saving video...","info");try{const n=await chrome.runtime.sendMessage({action:"addToFolder",folderId:e,url:t,resumeAtSeconds:o>0?o:void 0});n.success?l("Video saved successfully!","success"):l(n.message||n.error||"Failed to save video","error")}catch{l("An error occurred","error")}}function l(e,t){const o=document.createElement("div");o.className=`recall-toast recall-toast-${t}`,o.textContent=e,document.body.appendChild(o),setTimeout(()=>o.classList.add("recall-toast-show"),10),setTimeout(()=>{o.classList.remove("recall-toast-show"),setTimeout(()=>o.remove(),300)},3e3)}chrome.runtime.onMessage.addListener(e=>{(e==null?void 0:e.action)==="showToast"&&l(e.message,e.type||"info")});function T(){let e=window.location.href;new MutationObserver(()=>{const o=window.location.href;o!==e&&(e=o,i())}).observe(document.body,{childList:!0,subtree:!0})}p();
})()
